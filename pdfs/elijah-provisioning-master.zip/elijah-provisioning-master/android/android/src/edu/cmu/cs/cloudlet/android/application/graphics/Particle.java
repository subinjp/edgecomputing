package edu.cmu.cs.cloudlet.android.application.graphics;

public class Particle {
	public double x, y;

}

