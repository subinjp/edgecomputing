package edu.cmu.cs.cloudlet.android.data;

public class JSONHandleUtil {

}
