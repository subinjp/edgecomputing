package edu.cmu.cs.cloudlet.android.application.graphics;

import android.view.Display;
import android.view.WindowManager;

public class VisualizationStaticInfo {
	public static int containerWidth = 0;
	public static int containerHeight = 0;
	public static int screenWidth = 0;
	public static int screenHeight = 0;
}
