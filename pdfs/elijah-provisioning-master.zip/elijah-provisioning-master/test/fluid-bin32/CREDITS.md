Primary implementor:
	[Doyub Kim](http://www.doyub.com/) (Microsoft)

Modified by:
	Kiryong Ha (Carnegie Mellon University, krha@cs.cmu.edu) 

